@extends('layouts.template-admin')

@section('content')
<div class="container my-5">
	@include('partials.admin_common_nav', ['active' => 'job_posting'])
	<h4><p align="center">Job posting Tracker</p></h4>
	<div class="row">
		<div class="offset-8 col-4 text-right mb-2">
			<form method="post" action="{{ route('job.posting.tracker.export') }}">
				@csrf
				<button class="btn btn-success" title="Export Job Postings"><i class="fa fa-download" aria-hidden="true"></i></button>
			</form>
		</div>
	</div>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>#</th>
				<th>Practice Area</th>
				<th>Posted on</th>
				<th>Firm Name</th> 
				<th>Total Vacancy</th>
				<th>Location</th>
				<th>No. of Application received</th>
			</tr>
		</thead>
		<tbody>
			@foreach($jobs as $job)
			<tr>
				<td>{{ $loop->iteration }}</td>
				<td>{{ $job->practiceArea->name }}</td>
				<td>{{ $job->created_at }}</td>
				<td>{{ $job->company->name }}</td>
				<td>{{ $job->no_of_vacancies }}</td>
				<td>{{ $job->location }}</td>
				<td>{{ $job->applications->count() }}</td>
			</tr>
			@endforeach
		</tbody>
	</table>
</div>
@endsection
	
	