<div class="mt-4 light-bg">
    <h6>Salary</h6>
    {{-- <input type="text" class="form-control search-form1" placeholder="Choose Date "> --}}
   
        
    <select class="form-control " name="Salary_Range">
        <option selected="" disabled="">Salary</option>
        <option value="10,000">10,000</option>
        <option value="10,000">10,000</option>
        <option value="20,000">20,000</option>
        <option value="15,000">15,000</option>
        <option value="25,000">25,000</option>
        <option value="30,000">30,000</option>
        <option value="35,000">35,000</option>
        <option value="37,000">37,000</option>
        <option value="50,000 above">50,000 above</option>

        
    </select>
</div>


