<div class="mt-4 light-bg">
    <h6>Experience</h6>
    {{-- <div class="mb-3"><input type="text" class="form-control search-form1" placeholder="Choose Duration"></div>
    <div>
        <input type="checkbox">
        <label for="">Work from home</label>
    </div>
    <div>
        <input type="checkbox" id="css">
        <label for="">Part time</label>
    </div> --}}
    <select class="form-control " name="minimum_experience">
        <option selected="" disabled="">Year of Experience</option>
        <option value="fresher">Fresher</option>
        <option value="1 Yr">1 Yr</option>
        <option value="2 Yrs">2 Yrs</option>
        <option value="3 Yrs">3 Yrs</option>
        <option value="4 Yrs">4 Yrs</option>
        <option value="5 Yrs">5 Yrs</option>
        <option value="6-9 Yrs">6-9 Yrs</option>
        <option value="10-15 Yrs">10-15 Yrs</option>
        <option value="15 above">15 above</option>
    </select>
</div>