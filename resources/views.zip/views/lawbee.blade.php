@extends('layouts.template')

@section('content')
<section>
	<div class="container">
        <h3>Job Description</h3>
    
    </div>
</section>
@endsection